# Craft Notes — Structure, Prose, Voice

**Phase:** 4 (craft) · standalone segment of a phased run (`phase=4`) · draft `drafts/v1.md` (`draftId: 01M5Y4YPQGAWBCDE3XDDGR6CK8`)
**Input read:** `agents/editor/00-piece-brief.md` (Phase 0, complete)
**Not in scope here:** claim verification (Phase 1, running separately), discourse/originality (Phase 2, disabled this run — `discourse=false`), argument rigor (Phase 3), synthesis (Phase 6). This file is restricted to the developmental, line, and voice critique proper to Phase 4; it does not render a verdict.

## Scope note (carried from the Piece Brief)

The file under review is a three-paragraph excerpt that ends mid-sentence-group: the fourth paragraph opens a new claim ("What none of these institutions assumed...") and stops one supporting sentence later, before the piece states what follows from it. Per the Piece Brief, I am treating the leading framing line as paratext and reviewing the essay proper (from "## A short history of the free library" on). Several of the findings below — especially under Structure — are shaped by the fact that this is a fragment, not a finished short piece, and I say so at each one rather than penalizing the draft for an ending it hasn't reached yet.

---

## Structure (developmental)

### 1. The opening earns its next sentence — protect it

> "The idea that a city should lend books to anyone, for nothing, is younger than it seems."

This is a well-built lede for the genre the Piece Brief identifies (popular-history-of-institutions explainer): it makes a concrete, checkable-feeling claim, uses a mild contrarian turn ("younger than it seems") to justify the reader's next five minutes, and "for nothing" is a sharper, more concrete word choice than the flatter "for free" would have been. Nothing to fix here; flag it as a pattern to preserve in revision, not to over-polish away.

### 2. The Boston/Library of Congress contrast is asserted, not connected — a sequencing gap

> "The Boston Public Library, established in 1848, is usually described as the first large free municipal library in the United States, and its founding argument was explicitly democratic... The Library of Congress, founded in 1850, served legislators rather than citizens for most of its first century."

The second sentence is doing comparative work — it is the foil that makes the first sentence's "free to anyone" claim mean something — but the prose never says so. There is no "by contrast," "unlike Boston," or even a "meanwhile" to signal that the reader is meant to read these two institutions against each other rather than as two items in a list. As written, a reader moving at normal speed could take the LoC sentence as a second, unrelated fact rather than the intended counter-example, and would have to reread the paragraph once the contrast becomes clear only in retrospect (if it ever does, since the excerpt never explicitly draws the comparison out). **Fix:** make the contrast explicit — e.g., "Not every contemporary institution worked this way: the Library of Congress, founded in 1850, served legislators rather than citizens for most of its first century." One clause of signposting converts an implicit juxtaposition the reader has to construct into a comparison the prose actually makes.

### 3. Proportion is inverted: the most interpretive claim gets the least room

The piece spends a full paragraph (3 sentences, ~75 words) establishing Carnegie's financing mechanism and the NYPL building — both well-documented, relatively low-interpretive-burden claims — and then opens its most interesting move, the shift from *who* could use the library to *when* ("What none of these institutions assumed was that reading happened only in daylight... their patrons worked during the day"), with a single sentence before stopping. This is the one claim in the piece that is genuinely argumentative rather than descriptive (it attributes a cause — working patrons — to a pattern — evening hours), and it is the thinnest-supported sentence in the draft (the Piece Brief independently flags it, C5, as "the most interpretive claim in the piece"). Structurally, the draft has its proportions backwards: the load-bearing turn gets a sentence, the scene-setting gets a paragraph. **This may simply be where the excerpt was cut** — if the next paragraph develops this claim at length, the proportion resolves itself. But as delivered, this is exactly the kind of rushed crux the structural review exists to catch, and the author should treat the hours/access claim as needing at least a paragraph of its own, not a closing flourish.

### 4. The ending doesn't land, it stops

The excerpt's last sentence — "Nineteenth-century reading rooms routinely stayed open into the evening, precisely because their patrons worked during the day" — is a premise awaiting its conclusion, not a closing beat. This is consistent with the file being a deliberate partial excerpt rather than a complete short piece (noted in the Piece Brief's thesis section as a major finding in its own right: no thesis is yet stated). I am not scoring this as a craft failure of the full piece, since the full piece hasn't been delivered; I flag it here only so that whoever synthesizes the letter knows Phase 4 could not evaluate an ending, only the runway toward one.

---

## Prose (line level)

### 5. A single antithesis construction is repeated four times in ~230 words — the piece's one stylistic tic

Name the habit: define the subject by contrast with what it is *not*, using "rather than," "not... but," or "none... assumed" as the hinge. Instances, in order of appearance:

1. "served **legislators rather than citizens** for most of its first century" (¶1)
2. "it made the library a standing line in the municipal budget **rather than** a gift that could be allowed to lapse" (¶2)
3. "it was designed as a reading room **for everyone, not** a stack for scholars" (¶2)
4. "**What none** of these institutions **assumed was** that reading happened only in daylight" (¶3)

Four uses of essentially one rhetorical move in a 230-word excerpt is a tic, not a style, and it is specifically the family of construction ("it's not X, it's Y") that elite readers are now primed to pattern-match as boilerplate cadence regardless of whether the piece is AI-assisted — the repetition makes the device visible as a device, which is the failure mode whether or not that's the cause. The second and third instances fall only one sentence apart, which is where it becomes noticeable on a straight read.

**Rewrite example**, collapsing #3 to remove the device without losing the content:
> Original: "The New York Public Library's main building on Fifth Avenue opened to the public in 1911, and it was designed as a reading room for everyone, not a stack for scholars."
> Revised: "The New York Public Library's main building on Fifth Avenue opened to the public in 1911 as a public reading room — its architects planned for browsing patrons, not cloistered scholars." *(or, varying the construction entirely:)* "...opened to the public in 1911, built around open stacks and a reading room that assumed a general-public patron, not a specialist one."

The fix isn't to ban the construction outright (#1 is load-bearing and reads cleanly on its own) — it's to use it once, not four times, and to let the other three sentences carry their contrasts through sentence structure instead of through the same grammatical hinge.

### 6. Economy and register are otherwise sound

No padding, throat-clearing, or redundant qualification found in the excerpt — sentences like "a detail that matters, because it made the library a standing line in the municipal budget rather than a gift that could be allowed to lapse" (¶2) do real explanatory work in a single clause rather than restating themselves. Register is consistent throughout: short declaratives, concrete dates, no academic hedging apparatus, no lurches into either jargon or casualness. This matches the general-interest long-form register the Piece Brief infers for the venue, and should be protected in revision — the fix in #5 should not be allowed to introduce throat-clearing in the name of varying sentence construction.

### 7. One hedge, placed on the one claim that needed it — minor note, not a finding

> "is **usually described as** the first large free municipal library in the United States"

This is the piece's only hedge, and it's correctly placed: "first" is a contestable superlative, and hedging it is the right move rather than overclaiming. By contrast, the adjacent date claims (Boston 1848, LoC 1850, NYPL 1911) are all stated with flat, unhedged confidence, which is normal practice for dates and not a problem in itself — but it does mean the piece's confidence is calibrated entirely at the level of "dates don't get hedged," with no apparent independent check on whether a given date is itself solid before being asserted flatly. That calibration question is Phase 1's job, not this one; flagging it here only because it's a true observation about how the prose allocates its certainty, and because a confidently flat, unhedged register (principle noted in the Piece Brief) raises the cost of any one of these dates turning out to be wrong — the prose gives the reader no signal to distinguish a well-established date from a shakier one.

---

## Voice

### 8. A real fingerprint exists, but it's doing too much of the work alone

The "fact, then annotate why it matters" move — state an institutional detail, then immediately gloss its significance in the same breath ("a detail that matters, because...") — is a genuine, distinguishing authorial habit, and it's the strongest voice element in the excerpt: it signals a writer who wants to show the reader the historian's reasoning, not just hand over a fact. That's a real strength and should survive revision.

The problem is that the antithesis construction flagged in #5 is currently carrying the *rest* of the piece's distinctiveness — it's the only other recurring move — and because it's overused, it reads less like a voice and more like a reflex. Right now the excerpt has one good idiosyncratic habit and one overused one; if the antithesis construction is varied down per #5, the "annotate the significance" move is distinctive enough to stand as the piece's voice on its own. As it stands, a reader skimming quickly would be more likely to notice the repeated grammar than the actual insight it's attached to.

### 9. No unearned authority detected in this excerpt

The piece doesn't claim expertise or certainty beyond what three paragraphs of institutional-history description actually requires — there's no "as every historian knows" or similar overreach. This is worth noting explicitly (per the instruction to report against interest): a shorter or weaker draft often compensates with inflated authority-signaling, and this one doesn't.

---

## Summary for the letter-writer (Phase 6)

- **Major (structural):** the Boston/LoC contrast needs explicit signposting (#2); proportion is backwards relative to where the argument's weight needs to fall (#3), though this may resolve once the excerpt is read in full.
- **Major (prose):** the four-instance antithesis tic (#5) is the single most fixable, highest-leverage line-level note — one rewrite direction given.
- **Minor/notes:** opening is a keeper (#1); economy and register are sound (#6); hedge placement is fine and not a finding, just an observation that ties into Phase 1's stakes (#7); the "annotate significance" habit is real voice and worth protecting (#8); no unearned-authority problem (#9).
- Craft judgment on the ending (#4) is explicitly withheld — the excerpt stops before the piece makes its point, which is a scope fact, not a verdict.

**Status: Phase 4 complete.** Full findings recorded above for synthesis in Phase 6; no overall verdict or rubric scoring rendered here (out of scope for this phase).

# Piece Brief — `drafts/v1.md`

**draftId:** 01M5Y4YPQGAWBCDE3XDDGR6CK8
**Protocol:** essay · **Claim cap:** 5 · **Voice mode:** ad_hoc (no persona supplied)

## Note on scope

The file under review opens with an explicit framing line ("The Standard/Base
excerpt leg of the RES.1 probe...") identifying it as a short excerpt leg of a
larger piece, carrying one planted factual error by design. I am treating the
framing line itself as paratext/metadata, not as part of the authored essay,
and reviewing the essay proper (the material from "## A short history of the
free library" onward) as the piece whose project I need to reconstruct. The
excerpt is three paragraphs and ends mid-thought — the fourth paragraph opens
a new claim ("What none of these institutions assumed...") and is cut off
before the essay reaches a stated point. This matters for every section below
and is flagged again where it bears on the verdict.

## Thesis

No thesis is actually stated in the excerpt as delivered. The closest
candidate, built from the piece's own trajectory, is: **the American free
public library was conceived from the outset as a deliberately egalitarian
civic institution — open to all, funded as a standing public commitment
rather than a one-time gift, and (per the final paragraph) designed around
the actual schedules of working patrons rather than elite or scholarly use.**
That last clause is where the excerpt stops, one sentence into its payoff
("Nineteenth-century reading rooms routinely stayed open into the evening,
precisely because their patrons worked during the day"), without yet stating
what follows from it. Per the operating principle that an unstateable thesis
is itself a major finding: **this is recorded as a major finding below** — as
delivered, the piece does not yet contain a thesis, only a well-built runway
toward one.

## Genre and project

A short narrative-historical explainer, in the popular-history-of-institutions
mode (the kind of piece that traces an idea — here, the free library — through
a handful of founding moments to make a present-tense point). Success on its
own terms would mean: establish the institution's founding democratic premise,
show how philanthropy and civic funding scaled it, and land on an insight the
reader didn't already have about what "free to all" actually required in
practice. The excerpt executes the first two moves capably and is one beat
from the third when it stops.

## Intended audience and venue bar

Not given; inferred. The prose — short declarative sentences, concrete dates
and dollar-free specifics, no footnotes or academic hedging, one institution
per paragraph — reads as general-interest online long-form (an Aeon-, Atlantic-,
or substantial-newsletter-style history piece) rather than an academic or trade
outlet. I am calibrating against that bar: it demands verified dates and
institutional facts (this is exactly the genre where an alert reader checks
the one surprising date), but not scholarly apparatus.

## Argument skeleton

1. **Founding contrast (¶1).** Boston Public Library (1848) is positioned as
   the first large free *municipal* library, with an explicitly democratic
   founding argument (educated public → self-government), against the Library
   of Congress, characterized as serving legislators rather than citizens for
   most of its first century.
   - This contrast is the load-bearing move of the opening: the whole "free to
     anyone" claim depends on there being a real foil (a contemporary library
     that was *not* free to anyone). If the foil's founding date is wrong, the
     contrast itself isn't necessarily broken (LoC was still legislative-only
     for a long period either way) — but a wrong date sitting next to a
     presented-as-precise "1848" is exactly the kind of error this genre's
     readers catch and that undermines trust in every other date in the piece.
2. **Scaling mechanism (¶2).** Carnegie's grants are presented as the
   mechanism that took the model national, with the municipal
   funding-commitment condition doing real argumentative work: it's what
   turns "a library" into "a civic institution with a budget line," which
   feeds the egalitarian-institution thesis.
3. **Flagship instantiation (¶2, NYPL).** The NYPL building is offered as the
   model's apotheosis — "a reading room for everyone, not a stack for
   scholars" — the clearest single-sentence statement of the piece's implicit
   values claim.
4. **Unstated pivot (¶3).** "What none of these institutions assumed was that
   reading happened only in daylight" sets up a claim about hours/access that
   would extend the egalitarian argument from *who* could use the library to
   *when* — but the supporting sentence is the last one in the excerpt, and no
   conclusion is drawn.

The skeleton is coherent and economical through step 3; step 4 is a thesis
statement that hasn't happened yet. Phase 3 (argument) will need to assess
steps 1–3 on their own, since the piece as delivered doesn't entitle a
verdict on an argument it hasn't finished making.

## Claim inventory (capped at 5, ranked by load-bearing weight)

| # | Claim (location) | Tier | Why this tier |
|---|---|---|---|
| C1 | "The Library of Congress, founded in **1850**, served legislators rather than citizens for most of its first century." (¶1, sentence 4) | **1 — load-bearing** | This is the piece's explicit founding-date foil for the Boston claim; a wrong date on a sentence built entirely out of precise dates is maximally checkable and maximally damaging if wrong. Escalated regardless of role per the "too good to check" rule — a clean, round-sounding date offered with no hedge is exactly the claim to verify first. |
| C2 | "The Boston Public Library, established in **1848**, is usually described as the first large free municipal library in the United States, and its founding argument was explicitly democratic..." (¶1, sentences 2–3) | **1 — load-bearing** | This is the founding premise the whole piece is built on; if the date or the "first large free municipal library" characterization is wrong, the opening contrast collapses. |
| C3 | "Carnegie's grants paid for well over a thousand library buildings across the United States between the 1880s and 1919... Carnegie's condition was that the town supply the land and commit to funding operations every year." (¶2, sentences 1–2) | **1 — load-bearing** | This is the scaling mechanism the second paragraph's argument depends on, and it makes a specific quantitative claim ("well over a thousand") plus a specific institutional-mechanism claim (the land-plus-maintenance condition) that the piece treats as doing causal work ("a detail that matters"). |
| C4 | "The New York Public Library's main building on Fifth Avenue opened to the public in **1911**, and it was designed as a reading room for everyone, not a stack for scholars." (¶2, sentence 3) | 2 — supporting | Supports but doesn't singlehandedly carry the argument; still a precise date plus a characterization of design intent that a knowledgeable reader could check. |
| C5 | "Nineteenth-century reading rooms routinely stayed open into the evening, precisely because their patrons worked during the day." (¶3, sentences 1–2) | 2 — supporting, but flagged | This is the most *interpretive* claim in the piece (a general pattern + an attributed cause, not a single dated fact), and it's the one the unstated thesis pivot depends on — worth checking because it's about to become load-bearing in whatever the next paragraph argues. |

Claim cap of 5 reached at C5; no further claims inventoried. (The piece is
short enough that this cap captures essentially everything checkable in it —
there is no material left over for a "skipped, lower priority" note.)

## Research agenda (for Phase 2, if run)

`discourse=false` for this run, so Phase 2 will not execute — but the starting
queries for a later discourse pass, recorded now per protocol:

- History of the American free public library movement / "library faith" as a
  historiographical concept (the Wayne Wiegand school of U.S. library
  history is the standard academic reference point for this territory).
- Carnegie library philanthropy: the specific terms of Carnegie grants
  (land + maintenance commitment) and secondary literature on how that
  shaped municipal library funding long-term.
- Library of Congress institutional history: founding date and its
  legislators-only character/reading-room access history.
- Boston Public Library founding documents / trustees' report (the
  "educated public as precondition of self-government" framing is close
  enough to canonical BPL founding rhetoric that it should be checked
  against the actual 1852 trustees' report language, not just restated).
- Nineteenth-century library/reading-room hours and working-class access —
  this is the thinnest-sourced claim in the piece (C5) and the one most
  likely to be a plausible-sounding generalization rather than a specific,
  checkable fact; the discourse/verification passes should prioritize it.
- No named interlocutors, schools of thought, or explicit prior work are
  cited or attacked in the piece, so there is no misrepresentation-check
  target yet; this itself is worth noting if the piece continues into
  argument territory that does engage other views.

## What Phase 1 (verification) must prioritize

Given `claim_cap=5` and `verification=true`: all five rows above should be
checked. **C1 (Library of Congress founding date) is the single highest-
priority claim in the piece** — it is a specific, round, unhedged date doing
explicit argumentative work in the first paragraph, which is exactly the
profile of a planted or careless error in this genre. C2's compound claim (date
+ superlative characterization) is second priority since it is the premise the
whole contrast rests on. C3's quantitative claim ("well over a thousand")
and funding-condition claim should both be checked, not just one. C4 and C5
should be checked but survive the piece's collapse less consequentially if
wrong.

## Status

Phase 0 complete. This brief is the input for Phase 1 (verification, next if
the run continues) and for whichever later phase reads it. No argument,
craft, or letter judgment is rendered here — those are out of scope for this
phase and this run segment (`phase=0`).

# Access report

Seat: editor
Mounted paths: 7
URLs fetched: 62
Blocked attempts: 67
Boundary violations: 0

## Mounted by top-level

- agents: 5
- drafts: 1
- manifest.md: 1

## Subagent scoping

- (none)
# Manifest

JRN-3BA68171AFA6-R6EXCERPT

- `correspondence/review/1/00-piece-brief.md`
- `correspondence/review/1/01-claim-ledger.json`
- `correspondence/review/1/01-claim-ledger.md`
- `correspondence/review/1/03-argument-notes.md`
- `correspondence/review/1/04-craft-notes.md`
- `correspondence/review/1/access-report.md`
- `correspondence/review/1/editors-letter.md`
- `correspondence/review/1/findings.json`
- `correspondence/review/1/rubric.json`
- `drafts/v1.md`

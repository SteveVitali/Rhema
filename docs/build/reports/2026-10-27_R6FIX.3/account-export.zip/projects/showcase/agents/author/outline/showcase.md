# Outline — The Extinction of Man

## The wager
- Extinction as the rule, not the exception
- Man's exemption is assumed, never argued

## The evidence geology gives
- Dominant taxa fall at their zenith
- No dominant species succeeded by its own descendants

## The menagerie
- The sea: crabs, then cephalopods
- The land: the migratory ants
- Everywhere: the new plague

## The close
- Ascendency as the eve of overthrow
- The reviewer's disbelief as the final beat

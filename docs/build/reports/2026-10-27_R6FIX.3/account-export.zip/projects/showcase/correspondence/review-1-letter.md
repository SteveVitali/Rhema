# Editor's letter — The Extinction of Man (v1)

## The verdict

A real argument with a real hole: the essay's hinge specimen is wrong on the fossil record by a factor of two, and one of its three extinctions never happened. The thesis — that humanity's tenure is not guaranteed — survives contact with modern paleontology; the evidence propping it does not. Revise before this goes anywhere. See finding 1.

## Major findings

Beyond the Paradoxides figure, the extinction roll — auk, bison, dodo — contains a survivor and a date outside the essay's own two-hundred-year window. And the speculative menagerie works only because the essay keeps labelling its conjectures as conjectures; the revision must preserve that honesty, not let the six-foot crab harden into a footnote.

## Strengths

The structure IS the argument: the sea twice, the land once, then everywhere. The geology analogy that opens the piece — dominant taxa fall without warning, and no dominant species is succeeded by its own descendants — is the load-bearing claim, and it holds. The close ("the hour of its complete ascendency has been the eve of its entire overthrow") is the sentence the essay exists for.

## Revision roadmap

Correct the Paradoxides figure and carry the correction in the open — an essay about unpreparedness can afford to show its own. Fix the extinction roll or drop the bison. Keep the conjecture labels on the menagerie; they are what separates this from prophecy.

## Considered and rejected

We considered recommending the Cephalopod section be cut for length; it does the essay's best imaginative work and stays. We also considered flagging the title as dated; it is the period's idiom, and the conceit depends on it.

# Response — The Extinction of Man (v2)

Accounting for the revision, the way the response letter always works: the six-foot crab is corrected in the open — *Paradoxides* tops out near fifteen inches and no complete trilobite has ever exceeded two and a half feet, so the claim now reads as the conjecture it always was. The extinction roll drops the bison, which survives. The conjecture labels on the menagerie stay, as the letter asked. Everything else in the roadmap stands.

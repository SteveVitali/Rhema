# Manifest

Showcase — a worked example

- `agents/author/outline/showcase.md`
- `correspondence/response-1-letter.md`
- `correspondence/review-1-letter.md`
- `drafts/v1.md`
- `drafts/v2.md`

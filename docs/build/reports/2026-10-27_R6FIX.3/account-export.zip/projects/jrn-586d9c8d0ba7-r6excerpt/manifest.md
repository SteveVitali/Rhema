# Manifest

JRN-586D9C8D0BA7-R6EXCERPT

- `drafts/v1.md`
